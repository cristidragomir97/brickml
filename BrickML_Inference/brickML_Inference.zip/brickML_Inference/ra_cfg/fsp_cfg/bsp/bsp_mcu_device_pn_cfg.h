/* generated configuration header file - do not edit */
#ifndef BSP_MCU_DEVICE_PN_CFG_H_
#define BSP_MCU_DEVICE_PN_CFG_H_
#define BSP_MCU_R7FA6M5BF2CBG
#define BSP_MCU_FEATURE_SET ('B')
#define BSP_ROM_SIZE_BYTES (1048576)
#define BSP_RAM_SIZE_BYTES (524288)
#define BSP_DATA_FLASH_SIZE_BYTES (8192)
#define BSP_PACKAGE_BGA
#define BSP_PACKAGE_PINS (176)
#endif /* BSP_MCU_DEVICE_PN_CFG_H_ */

/*
 * comms.h
 *
 *  Created on: 2 Oct 2019
 *      Author: b3800274
 */

#ifndef COMMS_H_
#define COMMS_H_


#include "hal_data.h"

#define RAW_COUNT_MS    120000
#define WAIT_FOREVER    0xFFFFFFFF
#define MAX_PACKET_SIZE 64

/* Function prototypes */
fsp_err_t comms_open(void);
fsp_err_t comms_send(uint8_t * p_src, uint32_t len, uint32_t period);
fsp_err_t comms_read(uint8_t * p_dest, uint32_t * len, uint32_t timeout_milliseconds);
fsp_err_t comms_close(void);

#endif /* COMMS_H_ */
